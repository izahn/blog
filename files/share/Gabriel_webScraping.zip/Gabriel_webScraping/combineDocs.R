downloadDir <- "/home/izahn/Documents/Work/Consulting/Gabriel_webScraping/downloaded"
library(xml2)
library(readr)
library(tibble)
library(tidyr)
library(dplyr)
library(stringi)
library(parallel)

dataFiles <- list.files(downloadDir, pattern = "xls", full.names = TRUE)

# remove leading blank line to produce valid xml (already done)
for(file in dataFiles) {
 x <- read_lines(file, locale = locale(encoding = "UTF-8"))
 stri_write_lines(x[x != ""], fname = file, sep = "\n")
}

## Read data into R and collapse
dataXML <- lapply(dataFiles, function(x) {try(read_xml(x), silent = TRUE)})
failed <- sapply(dataXML, function(x) class(x)[1] == "try-error")
problemDataXML <- dataXML[failed]
dataXML <- dataXML[!failed]


getXML <- function(xml) {
  rows <- xml_find_all(xml_ns_strip(xml), xpath = "//Row")
  nameCells <- xml_find_all(rows[[2]], xpath = "Cell")
  nameValues <- c(sapply(nameCells, xml_text), "year")
  nameValues[1:2] <- c("CODIGO",	"MUNICIPIO")
  cells <- sapply(rows[3:length(rows)], xml_find_all, xpath = "Cell",
                  simplify = FALSE)
  values <- rbind(sapply(cells[-1], xml_text), xml_text(cells[[1]][3]))
  values <- as_data_frame(t(values))
  names(values) <- nameValues
  return(gather(values, key = "column", value = "value", -CODIGO, -MUNICIPIO, -year))
}

dataExtracted <- lapply(dataXML, function(x) try(getXML(x), silent = TRUE))

dataFailed <- sapply(dataExtracted, function(x) class(x)[1] == "try-error")
dataNotExtracted <- dataExtracted[dataFailed]
dataExtracted <- dataExtracted[!dataFailed]

dataExtracted <- bind_rows(dataExtracted)

dataExtracted <- arrange(dataExtracted, CODIGO, MUNICIPIO, year)
dataExtracted$column <- gsub(" .*$", "", dataExtracted$column)

dataExtractedWide <- spread(dataExtracted, "column", "value", convert = TRUE)

write_csv(dataExtractedWide, path = "SistemaNacional.csv")

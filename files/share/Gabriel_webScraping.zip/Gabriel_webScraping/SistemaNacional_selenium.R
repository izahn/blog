## Demo script to download data from datos.sinim.gov.cl.
## Author: Ista Zahn
## email any questions to help@iq.harvard.edu

## The basic formula for each loop is:
## 1. find the menu element and click on it
## 2. extract the options from it
## 3. iterate over the options and go to step 1

## install.packages("RSelenium")

library(RSelenium)

## make sure we start with a clean slate.

rm(list = ls())

## Let R know where your browser downloads things.
downloadDir <- "/home/izahn/Documents/Work/Consulting/Gabriel_webScraping/downloaded"
errorDir <- "/home/izahn/Documents/Work/Consulting/Gabriel_webScraping/errors"
wait <- 0.05
retries <- 10
myBrowser <- "chrome"

if(!dir.exists(downloadDir)) dir.create(downloadDir)
if(!dir.exists(errorDir)) dir.create(errorDir)

## could be replaced by clicking the download button or using download.file etc.
downloadFile <- function(theURL, fname) {
  system2("curl", paste0("-o ", downloadDir, "/", fname, " -g -s -S ",
                         "'http://datos.sinim.gov.cl/datos_municipales/obtener_datos_municipales.php?",
                         theURL,
                         "'",
                         collapse = ""),
          stderr = paste0(errorDir, "/", fname, ".error"),
          wait = FALSE)
}

getParams <- function() {
    theURL <- remDr$executeScript("var getvar ='area[]='+$('#dato_area').val();
					getvar +='&subarea[]='+$('#dato_subarea').val();
					getvar +='&variables[]='+$('#variables').val();
					getvar +='&periodos[]='+$('#periodos').val();
					getvar +='&regiones[]='+$('#regiones').val();
					getvar +='&municipios[]='+$('#municipios').val();
					getvar +='&corrmon='+setFactor;
					return getvar;",
          args = list())[[1]]
    return(theURL)
}

keepGettingParams <- function(retries = 10, wait = 0.5) {
  params <- try(getParams())
  ntries <- 0
  while(class(params) == "try-error" && ntries < retries) {
    params <- try(getParams())
    ntries <- ntries + 1
    Sys.sleep(wait)
    wait <- wait*2
  }
  return(params)
}



## make sure the selenium server is available and running
## checkForServer()
startServer()
Sys.sleep(2)

## connect R to the server
remDr <- remoteDriver(browserName = myBrowser)

Sys.sleep(2)

remDr$open()

Sys.sleep(2)

## set more generous timeouts to avoid errors
remDr$setAsyncScriptTimeout(milliseconds = 10000)
remDr$setImplicitWaitTimeout(milliseconds = 10000)
remDr$setTimeout(type = "page load", milliseconds = 10000)

remDr$navigate("http://datos.sinim.gov.cl/datos_municipales.php")

## find all the top level menues
areaMenu <- remDr$findElement(using = "css selector", "#bar > nav > div.menu_busqueda > ul > li:nth-child(1) > a")
areaVariableMenu <- remDr$findElement(using = "css selector",  "#bar > nav > div.menu_busqueda > ul > li:nth-child(2) > a")
areaYearMenu <- remDr$findElement(using = "css selector", "#bar > nav > div.menu_busqueda > ul > li:nth-child(3) > a")
areaRegionMenu <- remDr$findElement(using = "css selector", "#bar > nav > div.menu_busqueda > ul > li:nth-child(4) > a")
areaMuniMenu <- remDr$findElement(using = "css selector", "#bar > nav > div.menu_busqueda > ul > li:nth-child(5) > a")

areaMenu$clickElement()
## find and click the search box
areaSearchBox <- remDr$findElement(using = "css selector", "#dato_area_chzn > ul > li > input")
areaSearchBox$clickElement()

## find and select the all areas option
areaMenuOption <- remDr$findElements(using = "css selector",  "#dato_area_chzn > div > ul > li")[[1]]
if(!areaSearchBox$isElementDisplayed()[[1]]) areaMenu$clickElement()
areaSearchBox$clickElement()
if(!areaMenuOption$isElementDisplayed()[[1]]) {
  if(!areaSearchBox$isElementDisplayed()[[1]]) areaMenu$clickElement()
  areaSearchBox$clickElement()
}
areaMenuOptionText <- unlist(areaMenuOption$getElementText())
areaMenuOption$clickElement()

## find and select the all subareas option
subAreaSearchBox <- remDr$findElement(using = "css selector", "#dato_subarea_chzn > ul > li > input")
areaMenu$clickElement()
if(!subAreaSearchBox$isElementDisplayed()[[1]]) areaMenu$clickElement()
subAreaSearchBox$clickElement()
## find and extract the sub menu options 
areaSubMenuOption <- remDr$findElements(using = "css selector",  "#dato_subarea_chzn > div > ul > li")[[1]]
if(!subAreaSearchBox$isElementDisplayed()[[1]]) areaMenu$clickElement()
subAreaSearchBox$clickElement()
if(!areaSubMenuOption$isElementDisplayed()[[1]]) {
  if(!subAreaSearchBox$isElementDisplayed()[[1]]) areaMenu$clickElement()
  subAreaSearchBox$clickElement()
}
areaSubMenuOptionText <- unlist(areaSubMenuOption$getElementText())
areaSubMenuOption$clickElement()

## find and click the variable menu
areaVariableMenu$clickElement()
## ## loop over Variables 25 at a time
areaVariableSearchBox <- remDr$findElement(using = "css selector", "#variables_chzn > ul > li > input")
if(!areaVariableSearchBox$isElementDisplayed()[[1]]) areaVariableMenu$clickElement()
areaVariableSearchBox$clickElement()
areaVariableMenuOptions <- remDr$findElements(using = "css selector", "#variables_chzn > div > ul > li")[-1]
activeOptions <- try(sapply(areaVariableMenuOptions, function(x) {
  grepl("active-result", x$getElementAttribute("class")[[1]]) &&
    !grepl("(indicador disponible a partir de)|(desde .*\\d{4})", x$getElementText()[[1]])
}) , silent = TRUE)
ntries <- 0
wait2 <- wait
while(class(activeOptions) == "try-error" && ntries < retries) {
  activeOptions <- try(sapply(areaVariableMenuOptions, function(x) {
    grepl("active-result", x$getElementAttribute("class")[[1]]) &&
      !grepl("(indicador disponible a partir de)|(desde .*\\d{4})", x$getElementText()[[1]])
  }) , silent = TRUE)
  ntries <- ntries + 1; Sys.sleep(wait2); wait2 <- wait2*2
}
areaVariableMenuOptions <- areaVariableMenuOptions[activeOptions]
n <- floor(length(areaVariableMenuOptions) / 25)
rem <- length(areaVariableMenuOptions) %% 25
r <- split(areaVariableMenuOptions[1:(length(areaVariableMenuOptions) - rem)], rep(1:n, each = 25))
areaVariableMenuOptions <- c(r, list(areaVariableMenuOptions[(1 + (length(areaVariableMenuOptions) - rem)):length(areaVariableMenuOptions)]))

## loop over variable options
for(variableOptions in areaVariableMenuOptions) {
  if(!areaVariableSearchBox$isElementDisplayed()[[1]]) areaVariableMenu$clickElement()
  areaVariableSearchBox$clickElement()
  variableOptionsText <-  unlist(sapply(variableOptions, function(x) unlist(x$getElementText())))
  variableOptionsText <- gsub(" +", "_", paste(variableOptionsText[1], variableOptionsText[length(variableOptionsText)], sep = ".."))
  replicate(50, try(areaVariableSearchBox$sendKeysToElement(list(key = "backspace")), silent = TRUE))
  for(variableOption in variableOptions) {
    if(!variableOption$isElementDisplayed()[[1]]) {
      if(!areaVariableSearchBox$isElementDisplayed()[[1]]) areaVariableMenu$clickElement()
      areaVariableSearchBox$clickElement()
    }
    selected <- try(variableOption$clickElement(), silent = TRUE)
    ntries <- 0
    wait2 <- wait
    while(class(selected) == "try-error" && ntries < retries) {
      if(!variableOption$isElementDisplayed()[[1]]) {
        if(!areaVariableSearchBox$isElementDisplayed()[[1]]) areaVariableMenu$clickElement()
        areaVariableSearchBox$clickElement()
      }
      selected <- try(variableOption$clickElement(), silent = TRUE)
      Sys.sleep(wait2)
      wait2 <- wait2*2
      ntries <- ntries + 1
    }
  }
### Ano loop
  ## find and click the year menu
  areaYearMenu$clickElement()
  ## find and click the search box
  areaYearSearchBox <- remDr$findElement(using = "css selector", "#periodos_chzn > ul > li > input")
  if(!areaYearSearchBox$isElementDisplayed()[[1]]) areaYearMenu$clickElement()
  areaYearSearchBox$clickElement()
  areaYearMenuOptions <- remDr$findElements(using = "css selector",  "#periodos_chzn > div > ul > li")
  ## loop over year options
  for(yroption in areaYearMenuOptions) {
    if(!areaYearSearchBox$isElementDisplayed()[[1]]) areaYearMenu$clickElement()
    areaYearSearchBox$clickElement()
    try(areaYearSearchBox$sendKeysToElement(list(key = "backspace")), silent = TRUE)
    try(areaYearSearchBox$sendKeysToElement(list(key = "backspace")), silent = TRUE)
    if(!yroption$isElementDisplayed()[[1]]) {
      if(!areaYearSearchBox$isElementDisplayed()[[1]]) areaYearMenu$clickElement()
      areaYearSearchBox$clickElement()
    }
    yroptionText <- unlist(yroption$getElementText())
    yroption$clickElement()
    cat("\nSelecting year", paste0(yroptionText, collapse = ", "), ".\n")
    ## find and select the all regions option
    areaRegionMenu$clickElement()
    areaRegionSearchBox <- remDr$findElement(using = "css selector", "#regiones_chzn > ul > li > input")
    if(!areaRegionSearchBox$isElementDisplayed()[[1]]) areaRegionMenu$clickElement()
    areaRegionSearchBox$clickElement()
    try(areaRegionSearchBox$sendKeysToElement(list(key = "backspace")), silent = TRUE)
    try(areaRegionSearchBox$sendKeysToElement(list(key = "backspace")), silent = TRUE)
    areaRegionMenuOption <- remDr$findElements(using = "css selector",  "#regiones_chzn > div > ul > li")[[1]]
    if(!areaRegionSearchBox$isElementDisplayed()[[1]]) areaRegionMenu$clickElement()
    areaRegionSearchBox$clickElement()
    if(!areaRegionMenuOption$isElementDisplayed()[[1]]) {
      if(!areaRegionSearchBox$isElementDisplayed()[[1]]) areaRegionMenu$clickElement()
      areaRegionSearchBox$clickElement()
    }
    areaRegionMenuOptionText <- unlist(areaRegionMenuOption$getElementText())
    areaRegionMenuOption$clickElement()
    ## loop over Muni 30 at a time
    areaMuniMenu$clickElement()
    areaMuniSearchBox <- remDr$findElement(using = "css selector", "#municipios_chzn > ul > li > input")
    if(!areaMuniSearchBox$isElementDisplayed()[[1]]) areaMuniMenu$clickElement()
    areaMuniSearchBox$clickElement()
    areaMuniMenuOptions <- remDr$findElements(using = "css selector",  "#municipios_chzn > div > ul > li")[-1]
    if(length(areaMuniMenuOptions) == 0) warning("Did not find and municipalities!")
    n <- floor(length(areaMuniMenuOptions) / 30)
    rem <- length(areaMuniMenuOptions) %% 30
    r <- split(areaMuniMenuOptions[1:(length(areaMuniMenuOptions) - rem)], rep(1:n, each = 30))
    areaMuniMenuOptions <- c(r, list(areaMuniMenuOptions[(1 + (length(areaMuniMenuOptions) - rem)):length(areaMuniMenuOptions)]))
    if(!areaMuniSearchBox$isElementDisplayed()[[1]]) areaMuniMenu$clickElement()
    ## loop over municipio options
    for(munioptions in areaMuniMenuOptions) {
      if(!areaMuniSearchBox$isElementDisplayed()[[1]]) areaMuniMenu$clickElement()
      areaMuniSearchBox$clickElement()
      munioptionsText <-  unlist(sapply(munioptions, function(x) unlist(x$getElementText())))
      munioptionsText <- paste(munioptionsText[1], munioptionsText[length(munioptionsText)], sep = "..")
      replicate(60, try(areaMuniSearchBox$sendKeysToElement(list(key = "backspace")), silent = TRUE))
      if(!areaMuniSearchBox$isElementDisplayed()[[1]]) areaMuniMenu$clickElement()
      areaMuniSearchBox$clickElement()
      for(munioption in munioptions) {
        if(!munioption$isElementDisplayed()[[1]]) {
          if(!areaMuniSearchBox$isElementDisplayed()[[1]]) areaMuniMenu$clickElement()
          areaMuniSearchBox$clickElement()
        }
        selected <- try(munioption$clickElement(), silent = TRUE)
        ntries <- 0
        wait2 <- wait
        while(class(selected) == "try-error" && ntries < retries) {
          if(!munioption$isElementDisplayed()[[1]]) {
            if(!areaMuniSearchBox$isElementDisplayed()[[1]]) areaMuniMenu$clickElement()
            areaMuniSearchBox$clickElement()
          }
          selected <- try(munioption$clickElement(), silent = TRUE)
          Sys.sleep(wait2)
          wait2 <- wait2*2
          ntries <- ntries + 1
        }
      }
      theURL <- keepGettingParams()
      fname <- make.names(paste(
        variableOptionsText,
        yroptionText,
        munioptionsText,
        paste(c(sample(letters, 4), ".xls"), collapse = ""),
        sep = "_"))
      downloadFile(theURL, fname)
    }
  }
}

#remDr$closeall()




